// TreePrinter.java
import java.io.File;

// Classe principale qui construit et affiche l'arborescence d'un répertoire.
public class TreePrinter {

    public static void main(String[] args) {
        // Vérifie qu'un argument (chemin du répertoire) est fourni
        if (args.length != 1) {
            System.err.println("Usage: java TreePrinter <directory path>");
            System.exit(1); // Termine le programme avec un code d'erreur
        }

        String path = args[0]; // Récupère le chemin du répertoire
        File rootFile = new File(path); // Crée un objet File pour le répertoire racine

        // Vérifie que le chemin est valide et correspond à un répertoire
        if (!rootFile.exists() || !rootFile.isDirectory()) {
            System.err.println("Invalid directory path");
            System.exit(1); // Termine le programme avec un code d'erreur
        }

        // Crée le composite racine pour le répertoire
        DirectoryComposite root = new DirectoryComposite(rootFile.getName());
        // Construit l'arborescence de manière récursive
        buildTree(root, rootFile);
        // Imprime l'arborescence à partir de la racine
        root.print("");
    }

    // Méthode récursive pour construire l'arborescence
    private static void buildTree(DirectoryComposite parent, File file) {
        File[] files = file.listFiles(); // Liste tous les fichiers et répertoires
        if (files != null) {
            for (File f : files) {
                if (f.isDirectory()) {
                    // Si c'est un répertoire, crée un composite et ajoute-le au parent
                    DirectoryComposite dir = new DirectoryComposite(f.getName());
                    parent.add(dir);
                    // Appelle récursivement buildTree pour ce répertoire
                    buildTree(dir, f);
                } else {
                    // Si c'est un fichier, crée une feuille et ajoute-la au parent
                    parent.add(new FileLeaf(f.getName()));
                }
            }
        }
    }
}
