// Component.java
// Classe abstraite représentant un élément de l'arborescence (un fichier ou un répertoire).
public abstract class Component {
    protected String name; // Nom du fichier ou du répertoire

    public Component(String name) {
        this.name = name; // Initialise le nom
    }

    // Méthode abstraite pour imprimer l'arborescence avec un préfixe donné.
    public abstract void print(String prefix);
}
