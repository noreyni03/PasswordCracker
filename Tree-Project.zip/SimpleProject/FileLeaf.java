// FileLeaf.java
// Classe représentant un fichier (une feuille dans l'arborescence).
public class FileLeaf extends Component {

    public FileLeaf(String name) {
        super(name); // Appelle le constructeur de la classe parente pour initialiser le nom
    }

    @Override
    public void print(String prefix) {
        // Imprime le nom du fichier avec le préfixe donné
        System.out.println(prefix + name);
    }
}
