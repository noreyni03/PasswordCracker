// DirectoryComposite.java
import java.util.ArrayList;
import java.util.List;

// Classe représentant un répertoire (un composite dans l'arborescence).
public class DirectoryComposite extends Component {
    // Liste des enfants (fichiers et sous-répertoires)
    private List<Component> children = new ArrayList<>();

    public DirectoryComposite(String name) {
        super(name); // Appelle le constructeur de la classe parente pour initialiser le nom
    }

    // Ajoute un enfant (fichier ou sous-répertoire) au répertoire
    public void add(Component component) {
        children.add(component);
    }

    @Override
    public void print(String prefix) {
        // Imprime le nom du répertoire avec le préfixe donné
        System.out.println(prefix + name);
        // Imprime récursivement tous les enfants avec un préfixe supplémentaire
        for (Component component : children) {
            component.print(prefix + "    ");
        }
    }
}
